import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import syntaxtree.*;
import visitor.*;

public class Main {
   public static void main(String [] args) {
      try {
    	 File f = new File(args[0]); 
    	 InputStream i = new FileInputStream(f);
         Node root = new MiniExpr(i).Goal();
         System.out.println("Program parsed successfully");
         root.accept(new lab2_typecheck(),null); // Your assignment part is invoked here.
      }
      // | FileNotFoundException
      catch (ParseException | FileNotFoundException e) {
         System.out.println(e.toString());
      }
   }
} 




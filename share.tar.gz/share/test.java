int a;
int b;
bool c;
a = c+a;
c = c>b;
print a
